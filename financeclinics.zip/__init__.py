"""
FinanceClinics - API Blueprints
"""
